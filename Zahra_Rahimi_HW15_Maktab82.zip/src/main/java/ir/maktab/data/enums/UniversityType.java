package ir.maktab.data.enums;

public enum UniversityType {
    PUBLIC_DAILY, PUBLIC_EVENING, PRIVATE, CAMPUS, EXTRA_CAPACITY, PAYAME_NOUR, APPLIED_SCIENCE
}

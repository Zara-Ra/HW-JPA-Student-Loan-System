package ir.maktab.data.enums;

public enum DegreeGroup {
    GROUP1, GROUP2, GROUP3
}

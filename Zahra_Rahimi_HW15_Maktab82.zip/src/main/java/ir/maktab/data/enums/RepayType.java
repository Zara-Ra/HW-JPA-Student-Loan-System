package ir.maktab.data.enums;

public enum RepayType {
    EACH_SEMESTER, EACH_GRADE
}

package ir.maktab.data.enums;

public enum CityType {
    CAPITAL, METROPOLIS, OTHER
}

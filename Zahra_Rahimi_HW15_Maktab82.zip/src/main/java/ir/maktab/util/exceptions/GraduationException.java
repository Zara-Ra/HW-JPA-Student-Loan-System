package ir.maktab.util.exceptions;

public class GraduationException extends RuntimeException {
    public GraduationException(String message) {
        super(message);
    }

}

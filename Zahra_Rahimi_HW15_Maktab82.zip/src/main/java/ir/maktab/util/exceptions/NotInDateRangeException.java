package ir.maktab.util.exceptions;

public class NotInDateRangeException extends RuntimeException {
    public NotInDateRangeException(String message) {
        super(message);
    }

}
